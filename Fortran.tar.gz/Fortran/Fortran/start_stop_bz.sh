#!/bin/sh

# Stop bz (bz continues running but stops mining)
curl http://localhost:4014/rig_command?command=stop

# Start bz (bz reconnects to the pools and starts mining again)
#curl http://localhost:4014/rig_command?command=start

read -p "Press [Enter] key to start continue..."