#!/bin/sh

# replace 0000 with your address

# coolpool
./bzminer -a canxium -w 0000 -p ethstratum+tcp://cau.coolpool.top:16003 --nc 1

read -p "Press [Enter] key to start continue..."