#!/bin/sh

# replace 0000 with your address

# mining4people
./bzminer -a larissa -w 0000 -p ethstratum+ssl://na.mining4people.com:23344 --nc 1

read -p "Press [Enter] key to start continue..."