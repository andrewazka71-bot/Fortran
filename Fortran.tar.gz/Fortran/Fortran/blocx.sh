#!/bin/sh

# replace 0000 with your wallet address

# herominers
./bzminer.exe -a blocx -w 0000 -p pool.woolypooly.com:3148 --nc 1

read -p "Press [Enter] key to start continue..."