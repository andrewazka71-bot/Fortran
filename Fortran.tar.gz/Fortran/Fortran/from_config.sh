#!/bin/sh
./bzminer -c config.txt
read -p "Press [Enter] key to start continue..."